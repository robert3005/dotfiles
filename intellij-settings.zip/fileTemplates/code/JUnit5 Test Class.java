#parse("Palantir License.java")
final class ${NAME} {
  ${BODY}
}
