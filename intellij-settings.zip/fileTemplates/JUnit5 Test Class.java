#parse("File Header.java")
final class ${NAME} {
  ${BODY}
}
