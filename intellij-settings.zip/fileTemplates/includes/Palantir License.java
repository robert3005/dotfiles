/*
 * Copyright 2015 Palantir Technologies, Inc. All rights reserved.
 */
 
 